
PCB - v1 2022-05-06 9:58am
==============================

This dataset was exported via roboflow.ai on May 6, 2022 at 2:00 AM GMT

It includes 4 images.
Defect are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


